const LibCDirs = @This();
const builtin = @import("builtin");

const std = @import("../std.zig");
const Io = std.Io;
const LibCInstallation = std.zig.LibCInstallation;
const Allocator = std.mem.Allocator;
const Path = std.Build.Cache.Path;

libc_include_dir_list: []const []const u8,
libc_installation: ?*const LibCInstallation,
libc_framework_dir_list: []const []const u8,
sysroot: ?[]const u8,

pub fn detect(
    arena: Allocator,
    io: Io,
    zig_lib_dir: Path,
    target: *const std.Target,
    is_native_abi: bool,
    link_libc: bool,
    libc_installation: ?*const LibCInstallation,
    environ_map: *const std.process.Environ.Map,
) LibCInstallation.FindError!LibCDirs {
    if (!link_libc) {
        return .{
            .libc_include_dir_list = &[0][]u8{},
            .libc_installation = null,
            .libc_framework_dir_list = &.{},
            .sysroot = null,
        };
    }

    if (libc_installation) |lci| {
        return detectFromInstallation(arena, target, lci);
    }

    // If linking system libraries and targeting the native abi, default to
    // using the system libc installation.
    if (is_native_abi and !target.isMinGW()) {
        const libc = try arena.create(LibCInstallation);
        libc.* = LibCInstallation.findNative(arena, io, .{
            .target = target,
            .environ_map = environ_map,
        }) catch |err| switch (err) {
            error.CCompilerExitCode,
            error.CCompilerCrashed,
            error.CCompilerCannotFindHeaders,
            error.UnableToSpawnCCompiler,
            error.DarwinSdkNotFound,
            => |e| {
                // We tried to integrate with the native system C compiler,
                // however, it is not installed. So we must rely on our bundled
                // libc files.
                if (std.zig.target.canBuildLibC(target)) {
                    return detectFromBuilding(arena, zig_lib_dir, target);
                }
                return e;
            },
            else => |e| return e,
        };
        return detectFromInstallation(arena, target, libc);
    }

    // If not linking system libraries, build and provide our own libc by
    // default if possible.
    if (std.zig.target.canBuildLibC(target)) {
        return detectFromBuilding(arena, zig_lib_dir, target);
    }

    // If zig can't build the libc for the target and we are targeting the
    // native abi, fall back to using the system libc installation.
    // On windows, instead of the native (mingw) abi, we want to check
    // for the MSVC abi as a fallback.
    const use_system_abi = if (builtin.os.tag == .windows)
        target.abi == .msvc or target.abi == .itanium
    else
        is_native_abi;

    if (use_system_abi) {
        const libc = try arena.create(LibCInstallation);
        libc.* = try LibCInstallation.findNative(arena, io, .{
            .verbose = true,
            .target = target,
            .environ_map = environ_map,
        });
        return detectFromInstallation(arena, target, libc);
    }

    return .{
        .libc_include_dir_list = &.{},
        .libc_installation = null,
        .libc_framework_dir_list = &.{},
        .sysroot = null,
    };
}

fn detectFromInstallation(arena: Allocator, target: *const std.Target, lci: *const LibCInstallation) !LibCDirs {
    var list = try std.array_list.Managed([]const u8).initCapacity(arena, 5);

    list.appendAssumeCapacity(lci.include_dir.?);

    const is_redundant = std.mem.eql(u8, lci.sys_include_dir.?, lci.include_dir.?);
    if (!is_redundant) list.appendAssumeCapacity(lci.sys_include_dir.?);

    if (target.os.tag == .windows) {
        if (std.fs.path.dirname(lci.sys_include_dir.?)) |sys_include_dir_parent| {
            // This include path will only exist when the optional "Desktop development with C++"
            // is installed. It contains headers, .rc files, and resources. It is especially
            // necessary when working with Windows resources.
            const atlmfc_dir = try std.fs.path.join(arena, &[_][]const u8{ sys_include_dir_parent, "atlmfc", "include" });
            list.appendAssumeCapacity(atlmfc_dir);
        }
        if (std.fs.path.dirname(lci.include_dir.?)) |include_dir_parent| {
            const um_dir = try std.fs.path.join(arena, &[_][]const u8{ include_dir_parent, "um" });
            list.appendAssumeCapacity(um_dir);

            const shared_dir = try std.fs.path.join(arena, &[_][]const u8{ include_dir_parent, "shared" });
            list.appendAssumeCapacity(shared_dir);
        }
    }
    if (target.os.tag == .haiku) {
        const include_dir_path = lci.include_dir.?;

        const subdirs = &[_][]const u8{
            "os",                   "os/app",                  "os/device",               "os/drivers",
            "os/game",              "os/interface",            "os/kernel",               "os/locale",
            "os/mail",              "os/media",                "os/midi",                 "os/midi2",
            "os/net",               "os/opengl",               "os/storage",              "os/support",
            "os/translation",       "os/add-ons/graphics",     "os/add-ons/input_server", "os/add-ons/mail_daemon",
            "os/add-ons/registrar", "os/add-ons/screen_saver", "os/add-ons/tracker",      "os/be_apps/NetPositive",
            "os/be_apps/Tracker",   "bsd",                     "glibc",                   "gnu",
        };
        for (subdirs) |subdir| {
            const path = try std.fs.path.join(arena, &[_][]const u8{ include_dir_path, subdir });
            try list.append(path);
        }
    }

    const frameworks: []const []const u8 = if (target.os.tag.isDarwin()) try arena.dupe([]const u8, &.{
        try std.fs.path.join(arena, &.{ lci.darwin_sdk_dir.?, "System", "Library", "Frameworks" }),
    }) else &.{};

    return .{
        .libc_include_dir_list = list.items,
        .libc_installation = lci,
        .libc_framework_dir_list = frameworks,
        .sysroot = if (target.os.tag.isDarwin()) lci.darwin_sdk_dir.? else null,
    };
}

pub fn detectFromBuilding(arena: Allocator, zig_lib_dir: Path, target: *const std.Target) !LibCDirs {
    const s = std.fs.path.sep_str;

    if (target.os.tag.isDarwin()) {
        const list = try arena.alloc([]const u8, 1);
        list[0] = try arena.print("{f}" ++ s ++ "libc" ++ s ++ "include" ++ s ++ "any-darwin-any", .{zig_lib_dir});
        return .{
            .libc_include_dir_list = list,
            .libc_installation = null,
            .libc_framework_dir_list = &.{},
            .sysroot = null,
        };
    }

    const generic_name = libCGenericName(target);
    // Some architecture families are handled by the same set of headers.
    const arch_name = if (target.isMuslLibC() or target.isWasiLibC())
        std.zig.target.muslArchNameHeaders(target.cpu.arch)
    else if (target.isGnuLibC())
        std.zig.target.glibcArchNameHeaders(target.cpu.arch)
    else if (target.isFreeBSDLibC())
        std.zig.target.freebsdArchNameHeaders(target.cpu.arch)
    else if (target.isNetBSDLibC())
        std.zig.target.netbsdArchNameHeaders(target.cpu.arch)
    else if (target.isOpenBSDLibC())
        std.zig.target.openbsdArchNameHeaders(target.cpu.arch)
    else
        @tagName(target.cpu.arch);
    const os_name = @tagName(target.os.tag);
    const abi_name = if (target.isMuslLibC())
        std.zig.target.muslAbiNameHeaders(target.abi)
    else if (target.isGnuLibC())
        std.zig.target.glibcAbiNameHeaders(target.abi)
    else if (target.isNetBSDLibC())
        std.zig.target.netbsdAbiNameHeaders(target.abi)
    else
        @tagName(target.abi);
    const arch_include_dir = try arena.print("{f}" ++ s ++ "libc" ++ s ++ "include" ++ s ++ "{s}-{s}-{s}", .{
        zig_lib_dir, arch_name, os_name, abi_name,
    });
    const generic_include_dir = try arena.print("{f}" ++ s ++ "libc" ++ s ++ "include" ++ s ++ "generic-{s}", .{
        zig_lib_dir, generic_name,
    });
    const generic_arch_name = std.zig.target.osArchName(target);
    const arch_os_include_dir = try arena.print("{f}" ++ s ++ "libc" ++ s ++ "include" ++ s ++ "{s}-{s}-any", .{
        zig_lib_dir, generic_arch_name, os_name,
    });
    const generic_os_include_dir = try arena.print("{f}" ++ s ++ "libc" ++ s ++ "include" ++ s ++ "any-{s}-any", .{
        zig_lib_dir, os_name,
    });

    const list = try arena.alloc([]const u8, 4);
    list[0] = arch_include_dir;
    list[1] = generic_include_dir;
    list[2] = arch_os_include_dir;
    list[3] = generic_os_include_dir;

    return .{
        .libc_include_dir_list = list,
        .libc_installation = null,
        .libc_framework_dir_list = &.{},
        .sysroot = null,
    };
}

fn libCGenericName(target: *const std.Target) [:0]const u8 {
    switch (target.os.tag) {
        .windows => return "mingw",
        .driverkit, .ios, .maccatalyst, .macos, .tvos, .visionos, .watchos => return "darwin",
        .freebsd => return "freebsd",
        .netbsd => return "netbsd",
        .openbsd => return "openbsd",
        else => {},
    }
    switch (target.abi) {
        .gnu,
        .gnuabin32,
        .gnuabi64,
        .gnueabi,
        .gnueabihf,
        .gnuf32,
        .gnusf,
        .gnux32,
        => return "glibc",
        .musl,
        .muslabin32,
        .muslabi64,
        .musleabi,
        .musleabihf,
        .muslf32,
        .muslsf,
        .muslx32,
        .none,
        .ohos,
        .ohoseabi,
        => return "musl",
        .eabi,
        .eabihf,
        .abin32,
        .x32,
        .ilp32,
        .android,
        .androideabi,
        .msvc,
        .itanium,
        .simulator,
        .call0,
        => unreachable,
    }
}
